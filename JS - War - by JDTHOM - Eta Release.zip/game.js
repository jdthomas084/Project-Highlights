const RANKS = ["DEUCE", "THREE", "FOUR", "FIVE", "SIX", "SEVEN", "EIGHT", "NINE", "TEN", "JACK", "QUEEN", "KING", "ACE", "LIL_JOKER", "BIG_JOKER"];
const SUITS = ["CLUBS", "HEARTS", "DIAMONDS", "SPADES", "ORBS", "STARS", "ARCS", "SWORDS", "FOOLS", "ROYALS", "EAGLES", "NAVIES", "JOKERS"];
//
let card_count = 0;//initialize for How many cards are in [deck[]]?
//
let p1_Points = 0;//initialize starting points
let p2_Points = 0;//initialize starting points
let p3_Points = 0;//initialize starting points
//

class Card {
    constructor(r, s) {
        this.r = r;
        this.s = s;
    }
    get rank_str() { return RANKS[this.r]; }
    get suit_str() { return SUITS[this.s]; }
}

// Internal deck (never exposed directly)
let deck = [];

// Build full deck once
function buildDeck() {
    deck = [];
    deck.push(new Card(13, 12));//Add the Little Joker
    deck.push(new Card(14, 12));//Add the Big Joker

    //Loop to create the standard cards
    for (let r = 0; r < 13; r++) {
        for (let s = 0; s < 12; s++) {
            deck.push(new Card(r, s));
        }
    }
}

// Fisher–Yates shuffle (optimal)
function shuffleDeck() {
    for (let i = deck.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [deck[i], deck[j]] = [deck[j], deck[i]];
    }
}

function build_and_shuffle(){
//
//Build and shuffle the Deck.
    buildDeck();//Add the cards to the Deck.
    //Shuffle the Deck 10 times.
    for(let i = 0; i < 10; i++){
        shuffleDeck();
    }
//
}

// Deal one card from the top and remove it from the Deck.
function dealOne() {
    return deck.length ? deck.pop() : null;
}

function count_Cards() {
    return deck.length ? deck.length : 0;
}

function populateP1Cards() {
    const list = document.querySelectorAll('#p1_Cards li');
    if (!list) return;

    list.forEach(li => {
        if (deck.length > 0) {
            const c = dealOne();
            li.textContent = c
                ? `${c.rank_str} OF ${c.suit_str}`
                : "No cards left";
        } else {
            li.textContent = "No cards left";
        }
    });
}

function populateP2Cards() {
    const list = document.querySelectorAll('#p2_Cards li');
    if (list.length === 0) return;

    list.forEach(li => {
        if (deck.length > 0) {
            const c = dealOne();
            li.textContent = c
                ? `${c.rank_str} OF ${c.suit_str}`
                : "No cards left";
        } else {
            li.textContent = "No cards left";
        }
    });
}

function populateP3Cards() {
    const list = document.querySelectorAll('#p3_Cards li');
    if (!list) return;

    list.forEach(li => {
        if (deck.length > 0) {
            const c = dealOne();
            li.textContent = c
                ? `${c.rank_str} OF ${c.suit_str}`
                : "No cards left";
        } else {
            li.textContent = "No cards left";
        }
    });
}

function first_Deal(){
    build_and_shuffle();
    populateP1Cards();
    populateP2Cards();
    populateP3Cards();
    card_count = count_Cards();
}

window.addEventListener('load', () => {
    if (document.readyState === 'complete') {
        alert('Page fully ready');
        first_Deal();
        enableUserCardDrop();
    }
});

function enableUserCardDrop() {
    const srcItems = document.querySelectorAll('#p3_Cards li');
    const target = document.getElementById('trickCard_p3');

    let dragged = null;

    srcItems.forEach(li => {
        li.addEventListener('dragstart', e => {
            dragged = li;
            e.dataTransfer.effectAllowed = 'move';
        });
    });

    target.addEventListener('dragover', e => {
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
    });

    target.addEventListener('drop', () => {
        if (!dragged) return;
        target.textContent = dragged.textContent;
        dragged.textContent = '';
        dragged = null;
    });
}

document.getElementById('btn_Evaluate').addEventListener('click', () => {
    const slots = document.querySelectorAll('#trick li');
    if (slots.length !== 3) return;

    const parsed = [...slots].map(li => {
        const txt = li.textContent.trim();
        const [rank, , suit] = txt.split(' ');
        return {
            rankIndex: RANKS.indexOf(rank),
            suitIndex: SUITS.indexOf(suit),
            label: txt
        };
    });

    parsed.sort((a, b) => {
        if (a.rankIndex === b.rankIndex) {
            return b.suitIndex - a.suitIndex;
        }
        return b.rankIndex - a.rankIndex;
    });

    alert(`Winner: ${parsed[0].label}`);
});

document.getElementById('btn_PlaceCard_P1').addEventListener('click', () => {
    const cards = document.querySelectorAll('#p1_Cards li');
    const slot = document.getElementById('trickCard_p1');

    if (!cards.length) return;

    const idx = Math.floor(Math.random() * cards.length);
    const src = cards[idx];

    if (src.textContent.trim() !== '') {
        slot.textContent = src.textContent;
        src.textContent = '';
    }
});

document.getElementById('btn_PlaceCard_P2').addEventListener('click', () => {
    const cards = document.querySelectorAll('#p2_Cards li');
    const slot = document.getElementById('trickCard_p2');

    if (!cards.length) return;

    const idx = Math.floor(Math.random() * cards.length);
    const src = cards[idx];

    if (src.textContent.trim() !== '') {
        slot.textContent = src.textContent;
        src.textContent = '';
    }
});

document.getElementById('btn_DealCards').addEventListener('click', () => {
    const groups = [
        document.querySelectorAll('#p1_Cards li'),
        document.querySelectorAll('#p2_Cards li'),
        document.querySelectorAll('#p3_Cards li')
    ];

    groups.forEach(list => {
        list.forEach(li => {
            if (li.textContent.trim() === '' && deck.length > 0) {
                const c = dealOne();
                li.textContent = c
                    ? `${c.rank_str} OF ${c.suit_str}`
                    : '';
            }
        });
    });
});
