// Obtain the current week's dates
let weekDates = getCurrentWeekDates();
// Declare an array of emojis with their corresponding descriptors
let emojis = [
    ['happy.png', 'Good Day'], 
    ['sad.png', 'Bad Day'], 
    ['crazy.png', 'What a day!'], 
    ['chill.png', 'Pretty chill']
];

// Target the container div
let container = document.getElementById('divContainer');

let randomEmoji = 0;
let imgEmoji;
let pEmoji;

for (i = 0; i <= weekDates.length - 1; i++) {
    // Generate a random number to select an emoji from the emojis array
    randomEmoji = Math.floor(Math.random() * emojis.length);

    // Create an image element and a paragraph element for the selected emoji and its descriptor
    imgEmoji = '<img src="images/' + emojis[randomEmoji][0] + '" />';
    pEmoji = '<p>' + emojis[randomEmoji][1] + '</p>';

    // Append the day of the week, the emoji image, and the descriptor to the container div
    if (pEmoji === '<p>' + emojis[1][1] + '</p>') {
        document.getElementById('emojiContainer').innerHTML += '<img src="images/poo.png" />';
        container.innerHTML += '<span class="color-bad">' + weekDates[i] + imgEmoji + pEmoji + '</span>';
    }
    else {
        container.innerHTML += '<span class="color-good">' + weekDates[i] + imgEmoji + pEmoji + '</span>';
    }
}

// Function to get the current week's dates in MM/DD format
function getCurrentWeekDates() {
  // Get today's date
  const today = new Date();
  // Initialize an array to hold the week's dates
  const week = [];

  // Loop through the next 7 days, starting from today
  for (let i = 0; i < 7; i++) {
    const d = new Date(today);
    d.setDate(today.getDate() + i);

    const month = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");

    // Format the date as MM/DD and add it to the week array
    week.push(`${month}/${day}`);
  }

  return week;
}