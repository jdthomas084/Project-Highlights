#CoPilot's Version of Knight's Tour, implemented

from typing import List, Tuple, Optional

MOVES: List[Tuple[int, int]] = [
    (2, 1), (1, 2), (-1, 2), (-2, 1),
    (-2, -1), (-1, -2), (1, -2), (2, -1)
]

def in_bounds(n: int, r: int, c: int) -> bool:
    return 0 <= r < n and 0 <= c < n

def solve_knights_tour(n: int, start_r: int, start_c: int) -> Optional[List[List[int]]]:
    board = [[-1] * n for _ in range(n)]
    board[start_r][start_c] = 0  # first move

    def backtrack(r: int, c: int, move_i: int) -> bool:
        if move_i == n * n - 1:
            return True

        for dr, dc in MOVES:
            nr, nc = r + dr, c + dc
            if in_bounds(n, nr, nc) and board[nr][nc] == -1:
                board[nr][nc] = move_i + 1
                if backtrack(nr, nc, move_i + 1):
                    return True
                board[nr][nc] = -1  # undo

        return False

    return board if backtrack(start_r, start_c, 0) else None


# Example usage:
if __name__ == "__main__":
    tour = solve_knights_tour(8, 0, 0)
    if tour:
        for row in tour:
            print(" ".join(f"{c:2}" for c in row))
    else:
        print("No tour found.")
