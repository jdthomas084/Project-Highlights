# This is a sample Python script.

# Author: Joshua Douglas Thomas
# Graduate Student - Wilmington University
# In this Solution, the Knight starts at programmer-set
# ([start_row],[start_col]) and traverses the unique
# moves on #the chessboard from its starting point.
# 41 moves occur successfully before the moves fail.

#7.26

board_size = 8

# 8x8 Grid
board = [['00']*board_size,
         ['00']*board_size,
         ['00']*board_size,
         ['00']*board_size,
         ['00']*board_size,
         ['00']*board_size,
         ['00']*board_size,
         ['00']*board_size]  # Shortcut for 8x8 '0' grid


horizontal = [2, 1, -1, -2, -2, -1, 1, 2]
vertical = [-1, -2, -2, -1, 1, 2, 2, 1]

h_v_list = list(zip(horizontal, vertical))

start_row = 0 # Set the starting row.
start_col = 0 # Set the starting column.

previous_moves_lst = [(start_row,start_col)]

# Place the Knight on the Chessboard
board[start_row][start_col] = 'NN'

print("Knight 'manually' positioned.")

'''
Function Definition
	Receives: the grid
  	Returns: Nothing.

  This function prints the chess board.
'''
def print_board(grid):
  for row in grid:
    print(row)


def test_move(move_h, move_v):
  if 0 <= move_h < 8 and 0 <= move_v < 8:
      if (move_h, move_v) not in previous_moves_lst:
        return True
  return None

counter = 0

# Step 1: Show the initial, unmoved position of the Knight
# letter 'N'
# print_board(board)

#Loop to move the Knight.
for move_number in range(0,41):
  counter += 1
  # Set the move Index programmatically using remainder operator
  index = move_number % 8

  #Set the Vertical move.
  move_v = vertical[index]
  #Set the Horizontal move.
  move_h = horizontal[index]

  #Reassign Row.
  new_row = start_row + move_v
  #Reassign Column.
  new_col = start_col + move_h

  for i in range(0, len(h_v_list)):
    proposed_x = start_row + h_v_list[i][0]
    proposed_y = start_col + h_v_list[i][1]

    proposed_tuple = (proposed_x, proposed_y)
    if test_move(proposed_x, proposed_y):
      previous_moves_lst.append((proposed_x, proposed_y))
      board[proposed_x][proposed_y] = str(f"{counter:2}")
      start_row = proposed_x
      start_col = proposed_y
      break

print_board(board)


# See PyCharm help at https://www.jetbrains.com/help/pycharm/
