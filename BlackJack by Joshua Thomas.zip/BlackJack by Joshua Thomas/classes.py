import random

# Fantasy rank + suit dictionaries
ranks = {
    'ACES': 1, 'DEUC': 2, 'THRE': 3, 'FOUR': 4, 'FIVE': 5, 'SIXS': 6,
    'SEVN': 7, 'EIGT': 8, 'NINE': 9, 'TENS': 10,
    'JACK': 11, 'QUEN': 12, 'KING': 13,
    'JKRS': {'LJKR': 14, 'BJKR': 15}
}

suits = {
    'CLUB': 1, 'HRTS': 2, 'DMND': 3, 'SPAD': 4,
    'STAR': 5, 'ARCS': 6, 'ORBS': 7, 'SWRD': 8,
    'FOOL': 9, 'EGLE': 10, 'NAVY': 11
}


class Card:
    def __init__(self, rank: str, suit: str, facing: bool):
        self.rank = rank
        self.suit = suit
        self.facing = facing

    def flip(self):
        self.facing = not self.facing

    def is_facing(self):
        return self.facing

    def __repr__(self):
        face_state = "FACE-UP" if self.facing else "FACE-DOWN"
        return f"{self.rank} OF {self.suit} {face_state}"


class Player:
    def __init__(self, number: int, name: str):
        self.number = number
        self.name = name
        self.is_house = (number == 1)
        self.hand = []
        self.bankroll = 100
        self.bet = 0

    def take(self, card):
        self.hand.append(card)

    def clear_hand(self):
        self.hand = []

    def __repr__(self):
        role = "HOUSE" if self.is_house else f"PLAYER {self.number - 1}"
        return f"{role} {self.name} (Hand={self.hand})"