from classes import ranks

def card_value(card):
    if card.rank in ranks:
        val = ranks[card.rank]
        if isinstance(val, int):
            return val

    if card.rank in ranks['JKRS']:
        return ranks['JKRS'][card.rank]

    raise ValueError("Unknown rank")

def hand_total(hand):
    return sum(card_value(c) for c in hand)

def is_bust(hand):
    return hand_total(hand) > 21

def dealer_play(house, deck):
    while hand_total(house.hand) < 17:
        from deck import deal_card
        card = deal_card(deck, face_up=True)
        house.take(card)
        if is_bust(house.hand):
            break

def place_bet(player):
    MIN_BET = 100
    MAX_BET = 1_000_000

    while True:
        try:
            bet = int(input(f"{player.name}, enter your bet (100 - 1000000): "))

            if bet < MIN_BET:
                print(f"Minimum bet is {MIN_BET}.")
                continue

            if bet > MAX_BET:
                print(f"Maximum bet is {MAX_BET}.")
                continue

            if bet > player.bankroll:
                print(f"You only have {player.bankroll} credits.")
                continue

            player.bet = bet
            player.bankroll -= bet
            return

        except ValueError:
            print("Enter a valid number.")


def resolve_bet(player, house):
    # Player busts → loses bet
    if is_bust(player.hand):
        print(f"{player.name} loses {player.bet}")
        return

    # House busts → player wins
    if is_bust(house.hand):
        print(f"{player.name} wins {player.bet}")
        player.bankroll += player.bet * 2
        return

    p_total = hand_total(player.hand)
    h_total = hand_total(house.hand)

    if p_total > h_total:
        print(f"{player.name} wins {player.bet}")
        player.bankroll += player.bet * 2

    elif p_total < h_total:
        print(f"{player.name} loses {player.bet}")

    else:
        print(f"{player.name} pushes")
        player.bankroll += player.bet

def determine_winner(players):
    house = players[1]
    house_total = hand_total(house.hand)

    print("\n=== WINNERS ===")
    for num, p in players.items():
        if num == 1:
            continue

        p_total = hand_total(p.hand)

        if is_bust(p.hand):
            print(f"{p.name} busts.")
        elif is_bust(house.hand):
            print(f"{p.name} beats the house!")
        elif p_total > house_total:
            print(f"{p.name} beats the house!")
        elif p_total < house_total:
            print(f"{p.name} loses to the house.")
        else:
            print(f"{p.name} pushes.")

def reset_round(players, deck):
    for p in players.values():
        p.clear_hand()
    from deck import shuffle_deck
    shuffle_deck(deck)