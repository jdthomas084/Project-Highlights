from classes import Player
from deck import build_deck, deal_card, deal_to_house
from logic import (
    place_bet, dealer_play, determine_winner,
    resolve_bet, reset_round, is_bust
)
from ui import show_table, show_status

if __name__ == "__main__":
    print("BlackJack 1.0")

    house = Player(1, input("Enter HOUSE name: "))
    player1 = Player(2, input("Enter Player 1 name: "))
    player2 = Player(3, input("Enter Player 2 name: "))
    player3 = Player(4, input("Enter Player 3 name: "))

    players = {1: house, 2: player1, 3: player2, 4: player3}

    for num, p in players.items():
        if num == 1:
            p.bankroll = 999_999_999
        else:
            p.bankroll = 100_000

    deck = build_deck()

    while True:
        reset_round(players, deck)

        # Bets
        for num, p in players.items():
            if num != 1:
                place_bet(p)

        # Deal initial cards
        deal_to_house(house, deck)

        for num, p in players.items():
            if num != 1:
                card = deal_card(deck, face_up=True)
                p.take(card)

        show_table(players)

        # Player turns
        for num in (2, 3, 4):
            p = players[num]
            while True:
                cmd = input(f"{p.name}, hit? (y/n): ")
                if cmd.lower() != "y":
                    break

                card = deal_card(deck, face_up=True)
                p.take(card)
                show_table(players)
                show_status(p)

                if is_bust(p.hand):
                    break

        # Dealer plays
        print("\nDealer drawing...")
        dealer_play(house, deck)

        # Reveal dealer's hidden card
        for c in house.hand:
            if not c.is_facing():
                c.flip()

        show_table(players)

        # Determine winners
        determine_winner(players)

        # Resolve bets
        for num, p in players.items():
            if num != 1:
                resolve_bet(p, house)

        again = input("Play another round? (y/n): ")
        if again.lower() != "y":
            print("\n=== FINAL POINT TOTALS ===")
            for num, p in players.items():
                show_status(p)

            print("\n=== FINAL BANKROLL SUMMARY ===")
            for num, p in players.items():
                if num != 1:  # exclude house
                    print(f"{p.name}: {p.bankroll} credits")

            print(f"{house.name} (House): {house.bankroll} credits")
            break
