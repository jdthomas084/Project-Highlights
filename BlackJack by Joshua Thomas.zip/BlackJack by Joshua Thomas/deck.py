from classes import Card, ranks, suits
import random

def build_deck():
    deck = []
    for suit_name in suits:
        for rank_name, rank_val in ranks.items():
            if rank_name == 'JKRS':
                for jk_name in rank_val:
                    deck.append(Card(jk_name, suit_name, False))
            else:
                deck.append(Card(rank_name, suit_name, False))
    return deck

def shuffle_deck(deck):
    random.shuffle(deck)

def deal_card(deck, face_up=True):
    card = random.choice(deck)
    deck.remove(card)
    if face_up:
        card.flip()
    return card

def deal_to_house(house, deck):
    # First card face-up
    c1 = deal_card(deck, face_up=True)
    house.take(c1)

    # Second card face-down
    c2 = deal_card(deck, face_up=False)
    house.take(c2)