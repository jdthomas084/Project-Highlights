from logic import hand_total, is_bust

def show_status(player):
    total = hand_total(player.hand)
    if is_bust(player.hand):
        print(f"{player.name} BUSTS with {total}!")
    else:
        print(f"{player.name} has {total} points.")

def show_table(players):
    print("\n=== TABLE ===")
    for p in players.values():
        cards = []
        for c in p.hand:
            cards.append(str(c) if c.is_facing() else "*")
        print(f"{p.name}: {' '.join(cards)}")
    print("================\n")