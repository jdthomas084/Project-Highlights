---

# **README.md**

```markdown
# Blackjack 1.0  
### A Modular Python Blackjack Engine  
**Author:** Joshua D. Thomas  
**Date:** October 14, 2026  
**Graduate Student – Wilmington University**

---

## 📌 Overview

Blackjack 1.0 is a modular, fantasy‑themed Blackjack engine written in Python 3.  
It features:

- A custom deck with unique ranks and suits  
- Multiple players + dealer (house)  
- Betting system  
- Bust logic  
- Dealer AI (hit until 17)  
- Face‑down dealer card  
- Round reset  
- Winner determination  
- Table‑style UI  
- Fully modular file structure  

This project is designed for clarity, extensibility, and teaching clean Python architecture.

---

## 📁 Project Structure

```
blackjack/
│
├── classes.py      # Card + Player classes
├── deck.py         # Deck building, shuffling, dealing
├── logic.py        # Game rules, betting, dealer AI, scoring
├── ui.py           # Table display + player status
└── main.py         # Main game loop
```

Each module is self‑contained and easy to expand.

---

## 🃏 Fantasy Deck

### **Ranks**
```
ACES, DEUC, THRE, FOUR, FIVE, SIXS,
SEVN, EIGT, NINE, TENS,
JACK, QUEN, KING,
LJKR, BJKR (Jokers)
```

### **Suits**
```
CLUB, HRTS, DMND, SPAD,
STAR, ARCS, ORBS, SWRD,
FOOL, EGLE, NAVY
```

Total deck size: **165 cards**

---

## 🎮 Gameplay Features

### ✔ Multiple Players  
Up to 3 players + the house.

### ✔ Betting System  
Each player starts with a bankroll of 100 credits.

### ✔ Dealer Logic  
The house draws until reaching **17 or busting**.

### ✔ Bust Detection  
Hands over 21 automatically lose.

### ✔ Face‑Down Dealer Card  
The dealer’s second card is hidden until the end of the round.

### ✔ Winner Determination  
Players win, lose, or push based on final totals.

### ✔ Multiple Rounds  
Play as many rounds as you want.

---

## ▶ Running the Game

From the project directory:

```bash
python main.py
```

You will be prompted to enter:

- House name  
- Player names  
- Bets  
- Hit/stand decisions  

The game continues until you choose to stop.

---

## 🔧 Extending the Engine

This project is intentionally modular.  
You can easily add:

- Splitting  
- Double‑down  
- Insurance  
- Side bets  
- GUI (Tkinter or Pygame)  
- Logging  
- Statistics tracking  
- Network multiplayer  

The clean separation of logic makes expansion straightforward.

---

## 📜 License

This project is provided for educational and personal use.  
Feel free to modify and extend it.

---

## 🙌 Acknowledgments

Created as part of graduate coursework at **Wilmington University**.  
Designed to demonstrate modular Python architecture, game logic, and clean code practices.

```

---

If you want, I can also generate:

- A **project logo**  
- A **requirements.txt**  
- A **GitHub‑ready description**  
- A **Pygame GUI version**  
- A **casino‑style ASCII UI**

Just tell me what direction you want to take this.