import pytest
from classes import Card, Player
from ui import show_status, show_table
from logic import hand_total

def test_show_status_bust(capsys):
    p = Player(2, "Josh")
    p.take(Card("KING", "CLUB", True))
    p.take(Card("QUEN", "CLUB", True))
    p.take(Card("JACK", "CLUB", True))

    show_status(p)
    captured = capsys.readouterr().out
    assert "BUSTS" in captured

def test_show_table(capsys):
    p = Player(2, "Josh")
    p.take(Card("ACES", "CLUB", True))
    p.take(Card("TENS", "CLUB", False))

    players = {2: p}
    show_table(players)

    out = capsys.readouterr().out
    assert "ACES OF CLUB FACE-UP" in out
    assert "*" in out  # masked card
