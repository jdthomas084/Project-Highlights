import pytest
from deck import build_deck, shuffle_deck, deal_card, deal_to_house
from classes import Player

def test_build_deck_size():
    deck = build_deck()
    assert len(deck) == 165  # 11 suits × 15 ranks

def test_shuffle_deck():
    deck = build_deck()
    before = deck.copy()
    shuffle_deck(deck)
    assert deck != before  # shuffled order

def test_deal_card():
    deck = build_deck()
    c = deal_card(deck, face_up=True)
    assert c.is_facing()
    assert c not in deck

def test_deal_to_house():
    deck = build_deck()
    house = Player(1, "Dealer")
    deal_to_house(house, deck)

    assert len(house.hand) == 2
    assert house.hand[0].is_facing()      # first card face-up
    assert not house.hand[1].is_facing()  # second card face-down