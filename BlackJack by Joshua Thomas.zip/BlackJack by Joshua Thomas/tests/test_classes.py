import pytest
from classes import Card, Player

def test_card_flip():
    c = Card("ACES", "CLUB", False)
    assert not c.is_facing()
    c.flip()
    assert c.is_facing()

def test_card_repr():
    c = Card("ACES", "CLUB", False)
    assert "ACES OF CLUB FACE-DOWN" in str(c)
    c.flip()
    assert "FACE-UP" in str(c)

def test_player_take():
    p = Player(2, "Josh")
    c = Card("ACES", "CLUB", True)
    p.take(c)
    assert len(p.hand) == 1
    assert p.hand[0].rank == "ACES"

def test_player_clear_hand():
    p = Player(2, "Josh")
    p.take(Card("ACES", "CLUB", True))
    p.clear_hand()
    assert p.hand == []