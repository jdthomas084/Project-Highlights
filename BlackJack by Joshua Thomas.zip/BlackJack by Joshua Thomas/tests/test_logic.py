import pytest
from classes import Card, Player
from logic import (
    card_value, hand_total, is_bust,
    dealer_play, place_bet, resolve_bet, reset_round
)
from deck import build_deck

def test_card_value_normal():
    c = Card("FIVE", "CLUB", True)
    assert card_value(c) == 5

def test_card_value_joker():
    c = Card("LJKR", "CLUB", True)
    assert card_value(c) == 14

def test_hand_total():
    hand = [
        Card("ACES", "CLUB", True),
        Card("TENS", "CLUB", True),
        Card("KING", "CLUB", True)
    ]
    assert hand_total(hand) == 1 + 10 + 13

def test_is_bust():
    hand = [
        Card("TENS", "CLUB", True),
        Card("KING", "CLUB", True),
        Card("QUEN", "CLUB", True)
    ]
    assert is_bust(hand)

def test_dealer_play_hits_until_17():
    deck = build_deck()
    dealer = Player(1, "Dealer")

    # Give dealer a low starting hand
    dealer.take(Card("ACES", "CLUB", True))
    dealer.take(Card("DEUC", "CLUB", True))

    dealer_play(dealer, deck)
    assert hand_total(dealer.hand) >= 17 or is_bust(dealer.hand)

def test_place_bet():
    p = Player(2, "Josh")
    p.bankroll = 100

    # simulate input
    def fake_input(prompt):
        return "20"

    place_bet.__globals__["input"] = fake_input
    place_bet(p)

    assert p.bet == 20
    assert p.bankroll == 80

def test_reset_round():
    deck = build_deck()
    p = Player(2, "Josh")
    p.take(Card("ACES", "CLUB", True))

    players = {1: Player(1, "Dealer"), 2: p}
    reset_round(players, deck)

    assert p.hand == []
